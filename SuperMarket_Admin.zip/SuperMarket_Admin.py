file1=open("SuperMarket.txt","r")
def authenticate(username,password):
    if username=="Sakshi" and password=="Sakshi@123":
        print("Login Successfull")
        print("\n","1.View List of Customers ","\n","2.Exit")
        ch=int(input("Enter Your Choice :"))    
        if ch==1:
            for i in file1:
                print(file1.readline(),end=" ")
        else:
            if ch==2:
                return
            else:
                print("Enter Valid Choice")
    else:
        print("Invalid Username or Password")
        print("Try Again!!!")
