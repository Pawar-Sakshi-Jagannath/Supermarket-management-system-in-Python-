from datetime import datetime    #Module datetime
import SuperMarket_Admin

class mgt:                      #Class Definition
    def display(self):
        print(10*" ","Welcome to SuperMarket Management System")
        return
    def itemlist(self):
        lists='''
--------------------------------------
A) Bevergages =>
--------------------------------------
            1] Juice  : RS 30/each
            2] Coffee : RS 60/each
            3] Milk   : RS 40/liter
            4] Soda   : RS 20/liter
            5] Tea    : RS 20
            6] Coke   : RS 20/each
---------------------------------------
---------------------------------------
B) Packaged Food =>
---------------------------------------
            1] Bread        : RS 50/KG
            2] Chips        : RS 100/KG
            3] Flour        : RS 120/KG
            4] Honey        : RS 300/KG
            5] Mayonnaise   : RS 100/KG
            6] Ketchup      : RS 150/KG
            7] Pasta        : RS 70/KG
            8] Egg          : RS 10/each
            9] Noodles      : RS 200/KG
           10] Peanut       : RS 300/KG
           11] Rice         : RS 150/KG
           12] Salt         : RS 20/KG
           13] Sugar        : RS 50/KG
           14] Cheese       : RS 250/KG
----------------------------------------
----------------------------------------
C) Fruits =>
----------------------------------------
            1] Apple     : RS 180/kg
            2] Carrot    : RS 100/kg
            3] Grapes    : RS 150/kg
            4] Lemons    : RS 8/each
            5] Oranges   : RS 200/kg
            6] Mushrooms : RS 100/kg
----------------------------------------
----------------------------------------
D) Stationary =>
----------------------------------------
            1] Notebook    : RS 50/each
            2] Pen         : RS 10/each
            3] Pencil      : RS  5/each
            4] Slate       : RS 20/each
            5] Pouch       : RS 40/each
            6] Papers      : RS 10/each
            7] HighLighter : RS 50/each
-----------------------------------------
-----------------------------------------
E) Personal Care =>
-----------------------------------------
            1] Shampoo      : RS 10/each
            2] Soap         : RS 30/each
            3] Facewash     : RS 70/each
            4] Perfume      : RS 100/each
            5] Toothbrush   : RS 30/each
------------------------------------------
'''
        print(lists)
        return
            
m1=mgt()                                       #Object Creation
m1.display()                                   #Calling function

choice=int(input("For Admin Enter 1 & For Customer Enter 2:"))
if(choice==1):
    username=input("Enter Username :")
    password=input("Enter Password :")
    SuperMarket_Admin.authenticate(username,password)
if(choice==2):
    name=input("Enter Your Name:")
    address=input("Enter Your Address :")
    mobno=input("Enter Your Mobile Number :")

    #list of items

    price=0
    pricelist=[]
    totalprice=0
    Finalfinalprice=0
    ilist=[]
    qlist=[]
    plist=[]

    #Rates for items
    
    items={'juice':30,'coffee':60,'milk':40,'soda':20,'tea':20,'coke':20,'bread':50,'chips':100,'flour':120,'honey':300,'mayonnaise':100,'ketchup':150,'pasta':70,'egg':10,'noodles':200,'peanut':300,'rice':150,'salt':20,'sugar':50,'cheese':250,'apple':180,'carrot':100,'grapes':150,'lemon':8,'orange':200,'mashroom':100,'notebook':50,'pen':10,'pencil':5,'slate':20,'pouch':40,'papers':10,'highlighter':50,'shampoo':10,'soap':30,'facewash':70,'perfume':100,'toothbrush':30,}

    option=int(input("For List of items press 1:"))

    if option==1:
        m1.itemlist()

    for i in range(len(items)):
        inp1=int(input("If you want to buy press 1 or press 2 for exit :"))
        if inp1==2:
            print("Bye !! See You Soon ")
            break
        if inp1==1:
            item1=input("Enter Your Items :")
            item=item1[0].lower()+item1[1:]
            quantity=int(input("Enter Quantity:"))
            if item in items.keys():
                price=quantity*(items[item])
                list1=(item,quantity,items,price)
                pricelist.append(list1)
                totalprice+=price
                ilist.append(item)
                qlist.append(quantity)
                plist.append(price)
                gst=(totalprice*5)/100
                finalamount=gst+totalprice
            else:
                print("Sorry You entered item is not available ")
        else:
            print("You entered Wrong quantity")

        inp=input("Can I bill the items (Yes or No):")
        if inp=="yes"or inp=="Yes":
            pass
            if finalamount!=0:
                print(26*"=","SuperMarket Management",25*"=")
                print(28*" ","PAY-SLIP")
                print("Name :",name,25*" ","Date :",datetime.now())
                print("Address :",address,24*" ","Mob No :",mobno)
                print(75*"-")
                print("Sno",8*" ","Items",8*" ","Quantity ",8*" ","Price ")
                for i in range(len(pricelist)):
                    print(i+1,10*" ",ilist[i],9*" ",qlist[i],16*" ",plist[i])
                print(75*"-")
                print("TotalAmount:",40*" ",'RS',totalprice)
                print("GST Amount :",40*" ","RS",gst)
                print(75*"-")
                print("FinalAmount:",40*" ",'RS',finalamount)
                print(75*"-")
                print(30*" ","THANK YOU")
                print(75*"-")
            
                str1="Name  :",name,"Address :",address,"Mob No :",mobno,"Total Price :",finalamount
                name1=str(str1)
            
                file=open("SuperMarket.txt","a+")                #File Handling
                file.write("\n")
                file.write(name1)
            
            file.close()
        
            
            




